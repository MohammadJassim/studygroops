class ActivitiesController < ApplicationController
  before_action :set_activity, only: [:show, :edit, :update, :destroy]
  before_action :login_required
  http_basic_authenticate_with :name => "admin", :password => "#{ADMPW}", :only => [:index]

  # GET /activities
  # GET /activities.json
  def index
    @activities = Activity.all
  end

  # GET /activities/1
  # GET /activities/1.json
  def show
  end

  # GET /activities/new
  def new
    @activity = Activity.new
  end

  # GET /activities/1/edit
  def edit
  end

  # POST /activities
  # POST /activities.json
  def create
    @activity = Activity.new(activity_params)

    if @activity.valid? then
      respond_to do |format|
        if @activity.save
          #format.html { redirect_to @activity, notice: 'Activity was successfully created.' }
          format.html { redirect_to study_group_url(@activity.study_group_id), notice: 'Activity successfully created.' }
          format.json { render :show, status: :created, location: @activity }
        else
	  Rails.logger.debug "Error creating new activity"
          format.html { redirect_to action: "new", study_group_id: @activity.study_group_id }
          format.json { render json: @activity.errors, status: :unprocessable_entity }
          flash[:error] = "Error: " + @activity.errors.full_messages.to_s
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to action: "new", study_group_id: @activity.study_group_id }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
        flash[:error] = "Error: " + @activity.errors.full_messages.to_s
	Rails.logger.debug "Error creating activity."
      end
    end
  end

  # PATCH/PUT /activities/1
  # PATCH/PUT /activities/1.json
  def update
    #set_activity_params(@activity)
    if @activity.valid? then
      respond_to do |format|
        if @activity.update(activity_params)
	  format.html { redirect_to session[:caller_url], notice: 'Activity was successfully updated.' }
        else
	  Rails.logger.debug "Error updating activity."
          format.html { redirect_to action: "edit", study_group_id: @activity.study_group_id }
          format.json { render json: @activity.errors, status: :unprocessable_entity }
	  flash[:error] = "Not updated: " + @activity.errors.full_messages.to_s
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to action: "edit", study_group_id: @activity.study_group_id }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
        flash[:error] = "Not updated: " + @activity.errors.full_messages.to_s
	Rails.logger.debug "Error while updating activity"
      end
    end
  end

  # DELETE /activities/1
  # DELETE /activities/1.json
  def destroy
    @activity.destroy
    respond_to do |format|
      format.html { redirect_to get_user_activities_url, notice: 'Activity was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def get_user_activities
    begin
      @activities = Activity.get_user_group_activities(current_user.id)
    rescue
      @activities = nil
    end
    respond_to do |format|
        format.html { render 'get_user_activities' }
        format.xml { render :xml => @user_activities }
    end
  end

  private
    def set_activity_id
      @activity_id = params[:id]
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_activity
      if params[:id].nil?
	if params[:study_group_id].nil? then return end
	@activity = Activity.find_by_study_group_id(params[:study_group_id])
      else
        @activity = Activity.find(params[:id])
      end
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def activity_params
      params.require(:activity).permit(:study_group_id, :activity_name, :activity_date, :notes, :status_id)
    end

    def set_activity_params(activity)
      params[:id] = activity.id
      params[:study_group_id] = activity.study_group_id 
      params[:activity_name] = activity.activity_name
      params[:activity_date] = activity.activity_date
      params[:notes] = activity.notes
      params[:status_id] = activity.status_id
    end  
end
