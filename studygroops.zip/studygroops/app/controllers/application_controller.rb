class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  before_action :login_required, :only => [:new, :index, :show, :edit, :update, :destroy, :get_user_groups]
  after_filter :caller_url, :only => [:new, :edit, :update, :show, :get_user_activities, :get_user_tasks, :get_user_groups, :get_user_posts] 
  #skip_before_filter :login_required, :only => ['hidden']
  protect_from_forgery with: :exception
  
  helper :all
  helper_method :current_user

  #def login_required
  #  if session[:user]
  #    return true
      #login_required = true
  #  end
  #  session[:return_to]=request.original_url
  #  login_required = false
  #  return login_required
  #end

  def login_required
    redirect_to('/login') if current_user.blank?
  end

  def redirect_to_stored
    if return_to = session[:return_to]
      session[:return_to]=nil
      redirect_to_url(return_to)
    else
      redirect_to :controller=>'users', :action=>'new'
    end
  end


  def upload
    uploaded_io = params[:activity][:picture]
    File.open(Rails.root.join('public', 'uploads', uploaded_io.original_filename), 'wb') do |file|
      file.write(uploaded_io.read)
    end
  end

  def caller_url
    session[:caller_url] = URI(request.referer || '').path
    @caller_url = session[:caller_url]
  end

  protected
    def authenticate_user!
      if logged_in?
	super
      else
	#redirect_to login_path, :notice => 'Please login to continue'
      end	
    end

    def logged_in?
	!current_user.nil?
    end

  private

    def current_user
      return unless session[:user]
      @current_user ||= User.find(session[:user]["id"])
    end

end
