class GroupDetailsController < ApplicationController
  before_action :set_group_detail, only: [:show, :edit, :update, :destroy, :new, :create]
  before_action :study_group_id, only: [:show, :edit, :update, :destroy, :new, :create]

  attr_accessor :study_group_id

  # GET /group_details
  # GET /group_details.json
  def index
    @group_details = GroupDetail.all
  end

  # GET /group_details/1
  # GET /group_details/1.json
  def show
  end

  # GET /group_details/new
  def new
    @group_detail = GroupDetail.new #(group_detail_params)
  end

  # GET /group_details/1/edit
  def edit
  end

  # POST /group_details
  # POST /group_details.json
  def create
    @group_detail = GroupDetail.new(group_detail_params)
    if @group_detail.valid? then 
      respond_to do |format|
        if @group_detail.save
          format.html { redirect_to study_group_url(@group_detail.study_group_id), id: @group_detail.study_group_id, notice: 'Group detail successfully created.' }
          #format.json { render :show, status: :created, location: @group_detail }
        else
	  format.html { redirect_to action: "new", study_group_id: @group_detail.study_group_id}
          format.json { render json: @group_detail.errors, status: :unprocessable_entity }
          flash[:error] = @group_detail.errors.full_messages
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to action: "new", study_group_id: @group_detail.study_group_id }
	format.json { render json: @group_detail.errors, status: :unprocessable_entity }
	flash[:error] = "Error: " + @group_detail.errors.full_messages.to_s 
      end
    end
  end

  # PATCH/PUT /group_details/1
  # PATCH/PUT /group_details/1.json
  def update
    if @group_detail.valid? then
      respond_to do |format|
        if @group_detail.update(group_detail_params)
          #format.html { redirect_to @group_detail, notice: 'Group detail was successfully updated.' }
          format.html { redirect_to study_group_url(@group_detail.study_group_id), notice: 'Group detail was successfully updated.' }
          format.json { render :show, status: :ok, location: @group_detail }
        else
          #format.html { render :edit, study_group_id: @group_detail.study_group_id }
	  flash[:error] = "Not updated: " + @group_detail.errors.full_messages.to_s
	  format.html { redirect_to action: "edit", study_group_id: @group_detail.study_group_id }
          format.json { render json: @group_detail.errors, status: :unprocessable_entity }
	  #flash[:error] = @group_detail.errors.full_messages
        end
      end
    else
	flash[:error] = "Not updated: " + @group_detail.errors.full_messages.to_s
        format.html { redirect_to action: "edit", study_group_id: @group_detail.study_group_id }
        format.json { render json: @group_detail.errors, status: :unprocessable_entity }
        #flash[:error] = @group_detail.errors.full_messages
    end
  end

  # DELETE /group_details/1
  # DELETE /group_details/1.json
  def destroy
    @group_detail.destroy
    respond_to do |format|
      format.html { redirect_to group_details_url, notice: 'Group detail was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    def validate_input
      return @group_detail.valid?  	
    end

    def study_group_id=(study_group_id)
      @study_group_id = study_group_id
    end

    def study_group_id
      @study_group_id	
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_group_detail
      if params[:id].nil?
	if params[:study_group_id].nil? then return end
	@group_detail = GroupDetail.find_by_study_group_id(params[:study_group_id])
      else
        @group_detail = GroupDetail.find(params[:id])
      end
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def group_detail_params
      params.require(:group_detail).permit(:study_group_id, :start_date, :end_date, :location)
    end
end
