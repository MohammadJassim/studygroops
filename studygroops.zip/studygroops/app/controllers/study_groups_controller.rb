class StudyGroupsController < ApplicationController
  before_action :login_required, :only => [:new, :index, :show, :edit, :update, :destroy, :get_user_groups, :create]
  #skip_before_filter :login_required, :except =>  :show
  before_action :set_study_group, only: [:index, :show, :edit, :update, :destroy]

  # GET /study_groups
  # GET /study_groups.json
  def index
    if logged_in? then
      if params[:search] then
	if !params[:search].empty? then
          @study_groups = StudyGroup.search_by_keyword(params[:search])
	else
	  @study_groups = StudyGroup.all
	end
      else
        @study_groups = StudyGroup.all
      end
    end
  end

  # GET /study_groups/1
  # GET /study_groups/1.json
  def show
  end

  # GET /study_groups/new
  def new
    flash[:error] = ""
    @study_group = StudyGroup.new
  end

  # GET /study_groups/1/edit
  def edit
  end

  # POST /study_groups
  # POST /study_groups.json
  def create
    @study_group = StudyGroup.new(study_group_params)
    flash[:error] = ""
    if @study_group.valid? then
      respond_to do |format|
        if @study_group.save
	  join_group
	  flash[:notice] = "Study group was successfully created!"
          format.html { return flash[:message] = "Study group was successfully created!" }
          format.json { render :show, status: :created, location: @study_group }
        else
	  #flash[:error] = @study_group.errors.full_messages
	  Rails.logger.debug "Error saving Study Group."
          format.html { render 'new' }
          format.json { render json: @study_group.errors, status: :unprocessable_entity }
        end
      end
    else
      respond_to do |format|
        flash[:error] = @study_group.errors.full_messages
	Rails.logger.debug "Study Group validation failed"
        format.html { render 'new' }
        format.json { render json: @study_group.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /study_groups/1
  # PATCH/PUT /study_groups/1.json
  def update
    respond_to do |format|
      if @study_group.update(study_group_params)
        format.html { redirect_to @study_group, notice: 'Study group was successfully updated.' }
        format.json { render :show, status: :ok, location: @study_group }
      else
	Rails.logger.debug "Error updating Study Group"
        format.html { render :edit }
        format.json { render json: @study_group.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /study_groups/1
  # DELETE /study_groups/1.json
  def destroy
    @study_group.destroy
    respond_to do |format|
      format.html { redirect_to study_groups_url, notice: 'Study group was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def join_group
    @membership = Membership.new
    if @study_group.nil?
	@group_id = params[:group_id]
    else
	@group_id = @study_group.id
    end

    @membership.study_group_id = @group_id
    @membership.user_id = current_user.id
    begin
      begin
	if @membership.save
	  redirect_to get_user_groups_url, notice: 'Membership to group successful'
	  return 
	else
	  Rails.logger.debug "Error during membership request"
	  flash[:notice] = 'Membership unsuccessful'
	end
      rescue ActiveRecord::RecordNotUnique => e
	flash[:notice] = "Membership unsuccessful. User already a member of this group."
	Rails.logger.debug "User already a member of this group"
      end
    rescue
      flash[:message] = 'Membership to group unsuccessful - ' + @membership.errors.to_s
      Rails.logger.debug "Membership unsuccessful."	
    end
  end

  def leave_group
    if @study_group.nil?
        @group_id = params[:group_id]
    else
        @group_id = @study_group.id
    end

    #@membership.study_group_id = @group_id
    #@membership.user_id = current_user.id
    @membership = Membership.where(:user_id => current_user.id, :study_group_id => @group_id)
    if !@membership.nil? then
      @membership.destroy(@membership[0].id)
      flash[:notice] = 'Membership successfully removed for group ' + @membership[0].study_group_id .to_s
    else
      flash[:message] = 'Membership could not be deleted'
      Rails.logger.debug "Membership could not be deleted"
    end 
    redirect_to get_user_groups_url #, :notice => 'Membership to group deleted.'
  end

  def search_by_location #(location)
    location = params[:search]
    if !location.nil? then
      #@result = StudyGroup.all :joins => :group_details, :coditions => {'location' => location }
      @study_groups = StudyGroup.search_by_location(location)
    end
    if @study_groups.empty? then
      redirect_to group_details_url
    end
    respond_to do |format|
      #format.html { render 'index' }
      format.xml { render :xml => @study_groups }
    end    	
  end

  def get_user_groups
    begin
      @user_groups = StudyGroup.get_current_user_groups(current_user.id)
    rescue
      @user_groups = nil #["No Groups"]
    end
    respond_to do |format|
	format.html { render 'get_user_groups' } 
	format.xml { render :xml => @user_groups }
    end
  end

  def get_group_members
    begin
      @group_members = StudyGroup.get_group_members(group_id)
    rescue
      @group_members = nil
    end
    respond_to do |format|
        format.html { render 'get_group_members' }
        format.xml { render :xml => @group_members }
    end
  end


  private
   # Use callbacks to share common setup or constraints between actions.
    def set_study_group
      begin	
        @study_group = StudyGroup.find(params[:id])
      rescue
	#@study_group = nil
      end
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def study_group_params
      params.require(:study_group).permit(:group_name, :description, :search)
    end
end
