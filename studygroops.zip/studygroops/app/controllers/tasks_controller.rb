class TasksController < ApplicationController
  before_action :set_task, only: [:show, :edit, :update, :destroy]
  http_basic_authenticate_with :name => "admin", :password => "#{ADMPW}", :only => [:index]

  # GET /tasks
  # GET /tasks.json
  def index
    @tasks = Task.all
  end

  # GET /tasks/1
  # GET /tasks/1.json
  def show
  end

  # GET /tasks/new
  def new
    @task = Task.new
  end

  # GET /tasks/1/edit
  def edit
  end

  # POST /tasks
  # POST /tasks.json
  def create
    @task = Task.new(task_params)
    if @task.valid? then
      respond_to do |format|
        if @task.save
          #format.html { redirect_to @task, notice: 'Task was successfully created.' }
          format.html { redirect_to session[:caller_url], notice: 'Task was successfully updated.' }
          format.json { render :show, status: :created, location: @task }
        else
	  Rails.logger.debug "Error creating new Task."
          format.html { render :new }
          format.json { render json: @task.errors, status: :unprocessable_entity }
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to action: "new", activity_id: @task.activity_id }
        format.json { render json: @task.errors, status: :unprocessable_entity }
        flash[:error] = "Error: " + @task.errors.full_messages.to_s
	Rails.logger.debug "Error creating Task."
      end
    end
  end

  # PATCH/PUT /tasks/1
  # PATCH/PUT /tasks/1.json
  def update
    if @task.valid? then
      respond_to do |format|
        if @task.update(task_params)
          #format.html { redirect_to @task, notice: 'Task was successfully updated.' }
	  format.html { redirect_to session[:caller_url], notice: 'Task was successfully updated.' }
          format.json { render :show, status: :ok, location: @task }
        else
          format.html { redirect_to action: "edit", activity_id: @task.activity_id }
          format.json { render json: @activity.errors, status: :unprocessable_entity }
          flash[:error] = "Error: " + @activity.errors.full_messages.to_s
	  Rails.logger.debug "Error updating Task."
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to action: "edit", activity_id: @task.activity_id }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
        flash[:error] = "Error: " + @activity.errors.full_messages.to_s
	Rails.logger.debug "Error while updating Task."
      end
    end
  end

  # DELETE /tasks/1
  # DELETE /tasks/1.json
  def destroy
    @task.destroy
    respond_to do |format|
      format.html { redirect_to get_user_tasks_url, notice: 'Task was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def get_user_tasks
    begin
      @tasks = Task.get_user_group_tasks(current_user.id)
    rescue
      @tasks = nil
    end
    respond_to do |format|
        format.html { render 'get_user_tasks' }
        format.xml { render :xml => @tasks }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_task
      @task = Task.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def task_params
      params.require(:task).permit(:activity_id, :task_detail, :due_date, :skills_applied, :status_id)
    end
end
