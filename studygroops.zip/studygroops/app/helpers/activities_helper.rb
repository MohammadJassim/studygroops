module ActivitiesHelper

  def get_group_activities(group_id)
    @group_activities = Activity.get_group_activities(group_id)
  end

end
