module ApplicationHelper

  def login_out
    if current_user.nil? then
      return 'Login'
    else
      return 'Logout'
    end
  end

  def displayOn
   return current_user.nil? ? "hidden" : "display"
   #   return false
   # else
   #   return true
   # end
  end

  def get_status_by_id(id)
    @status = Status.find_by_id(id)
    return @status.state
  end

  def get_study_group_by_id(id)
    @study_group = StudyGroup.find_by_id(id)
    return @study_group.group_name
  end


end
