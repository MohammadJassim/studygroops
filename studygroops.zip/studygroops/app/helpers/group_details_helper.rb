module GroupDetailsHelper

  def get_group_details(group_id)
    @user_group_details = GroupDetail.get_group_details(group_id)
  end

end
