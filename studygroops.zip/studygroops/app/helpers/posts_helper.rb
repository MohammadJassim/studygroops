module PostsHelper

  def get_group_posts(group_id)
    @group_posts = Post.get_group_posts(group_id)
  end

  def get_user_group_posts
    @posts = Post.get_user_group_posts(current_user.id)	
  end

end
