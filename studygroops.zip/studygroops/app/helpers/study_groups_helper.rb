module StudyGroupsHelper

  def join_link(user_id, group_id, group_list)
      is_member = false	
      @user_groups = StudyGroup.is_member_of_group(user_id, group_id)
      if !group_list.nil? then
      	group_list.each do |item|
      	  @user_groups.each do |user_group|
      	    if item.id == user_group.id then
	      is_member = true
	      return is_member	
	    else
	      is_member = false
            end
	  end
        end
      else
	is_member = true 
      end
      return is_member	
  end

  def get_group_members(group_id)
    @group_members = StudyGroup.get_group_members(group_id)
    group_user = []	
    @group_members.each do |member|
      group_user.push(member.user_id)
    end
    return group_user 
  end

  def is_member_of_group(user_id, group_id)
    @is_member = StudyGroup.is_member_of_group(user_id, group_id)
    if @is_member.empty? then
      return false
    else
      return true
    end
  end

end
