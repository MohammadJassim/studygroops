module TasksHelper

  def get_activity_tasks(activity_id)
    @tasks = Task.get_activity_tasks(activity_id)
  end

end
