class UserMailer < ActionMailer::Base
  default from: "#{EMAIL_USER}"

  def welcome_email(user)
	@user = user
	@url = "#{SITE_URL}"
	mail(to: @user.email, subject: 'Welcome email')
  end

  def reset_notification(user)
    @user = user
    @url = "http://#{SITE_URL}/reset/#{user.reset_code}"
    mail(to: @user.email, subject: 'Link to reset your password')
  end

  def user_message(from_email, to_email, message, email_subject)
    mail(to: to_email, from: from_email, subject: email_subject, body: message)
  end

end
