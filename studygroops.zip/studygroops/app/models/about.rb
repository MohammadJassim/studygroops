class About < ActiveRecord::Base
end
