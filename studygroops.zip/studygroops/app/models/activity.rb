class Activity < ActiveRecord::Base
  belongs_to :study_group
  belongs_to :status
  has_many :tasks
  belongs_to :membership, :foreign_key => 'study_group_id', :primary_key => 'study_group_id'

  validates_presence_of :study_group_id, :activity_name, :activity_date

  def self.get_group_activities(group_id)
    @activities = Activity.where(study_group_id: group_id).all
  end

  def self.get_user_group_activities(user_id)
    @activities = Activity.includes(:study_group).includes(:membership).where(:memberships => {:user_id => user_id}).all
  end

end
