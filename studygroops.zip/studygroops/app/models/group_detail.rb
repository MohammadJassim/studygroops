class GroupDetail < ActiveRecord::Base
  belongs_to :study_group #, class_name: group_detail
  #has_many :study_groups

  validates_presence_of :study_group_id, :location, :start_date 
  validates_length_of :location, :within => 3..100

  def self.get_group_details(group_id)
    @group_details = GroupDetail.where(study_group_id: group_id).all
  end
end
