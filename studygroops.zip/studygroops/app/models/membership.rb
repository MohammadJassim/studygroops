class Membership < ActiveRecord::Base
  belongs_to :study_group #, dependent: :destroy
  belongs_to :user

  validates_presence_of :study_group_id, :user_id
end
