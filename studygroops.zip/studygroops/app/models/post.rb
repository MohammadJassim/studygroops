class Post < ActiveRecord::Base
  belongs_to :study_group
  belongs_to :user
  has_many :comments, :dependent => :destroy
  belongs_to :membership, :primary_key => 'study_group_id', :foreign_key => 'study_group_id'

  validates_presence_of :title, :user_id, :study_group_id, :content

  def self.get_group_posts(group_id)
    @group_posts = Post.where(study_group_id: group_id).all
  end

  def self.get_user_group_posts(user_id)
    #@group_posts = Post.includes(:membership).where(:memberships => {user_id IN (?), user_id}).where(:posts => {:study_group_id => :study_group_id}).all
    @posts = Post.find_by_sql("select posts.* from posts inner join memberships where posts.study_group_id = memberships.study_group_id and posts.user_id = memberships.user_id and posts.study_group_id in (select memberships.study_group_id from memberships where memberships.user_id = #{user_id})")
  end
  
end
