class Repository < ActiveRecord::Base
end
