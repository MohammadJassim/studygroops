class StudyGroup < ActiveRecord::Base
  has_many :memberships, :foreign_key => "study_group_id", inverse_of: :study_group, dependent: :destroy
  has_many :users, :through => :memberships, dependent: :destroy
  has_one :group_detail
  has_many :activities
  has_many :tasks

  validates_presence_of :group_name, :description
  validates_length_of :group_name, :within => 1..50
  validates_length_of :description, :within => 1..255

  def self.get_current_user_groups(user_id)
    group_list = StudyGroup.includes(:memberships).where(:memberships => {user_id: user_id}).all
  end

  def self.is_member_of_group(user_id, group_id)
    group_list = StudyGroup.includes(:memberships).where(:memberships =>  {study_group_id: group_id}).where(:memberships => { user_id: user_id }).all
    return group_list
    #if group_list.nil? then return false else return true end
  end

  def self.get_group_members(group_id)
    @group_members = Membership.where(:memberships => {study_group_id: group_id}).all
  end

  def self.search_by_location(location)
    @result = StudyGroup.includes(:group_detail).where("group_details.location LIKE CONCAT('%',?,'%')", location).references(:group_detail).all   # { location: location }).all
  end

  def self.search_by_keyword(keyword)
    @result = StudyGroup.includes(:group_detail).where("group_name LIKE CONCAT('%',?,'%') OR description LIKE CONCAT('%',?,'%') OR group_details.location LIKE CONCAT('%',?,'%')", keyword, keyword, keyword).references(:group_detail).all #(:group_details => { location: locaion }).all
  end

end
