class Task < ActiveRecord::Base
  belongs_to :activity
  belongs_to :status
  #belongs_to :study_group #, :foreign_key => 'activity_id'
  belongs_to :membership #, :foreign_key => 'activity_id', :primary_key => 'study_group_id'
  #scope :for_user_tasks, -> {includes(:activity, :membership).where('memberships.study_group_id = activities.study_group_id')}
  validates_presence_of :activity_id, :task_detail, :due_date

  def self.get_activity_tasks(activity_id)
    @activity_tasks = Task.where(activity_id: activity_id).all
  end

  def self.get_user_group_tasks(user_id)
    #@tasks = Task.includes(:activity).includes(:study_group).includes(:membership).where(:memberships => {:user_id => user_id}).all
    @tasks = Task.find_by_sql("SELECT tasks.* FROM tasks INNER JOIN activities ON activities.id = tasks.activity_id LEFT OUTER JOIN memberships ON memberships.study_group_id = activities.study_group_id WHERE memberships.user_id = #{user_id}") 
  end
end
