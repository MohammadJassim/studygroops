require 'digest/sha1'

class User < ActiveRecord::Base
  has_many :memberships, :dependent => :destroy
  has_many :study_groups, :through => :memberships

  #has_many :members, class_name: "User", foreign_key: "user_id"
  #belongs_to :owner, class_name: "User"

  validates_length_of :login, :within => 3..40
  validates_length_of :hashed_password, :within => 5..40, :on => [:create, :update, :change_password]
  validates_presence_of :login, :email, :hashed_password, :password_confirmation, :salt, :on => :create
  validates_confirmation_of :hashed_password, :on=>:change_password
  validates_uniqueness_of :login, :email
  validates_confirmation_of :hashed_password, :on => :create
  validates_format_of :email, :multiline => true, :with => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i, :message => "Invalid email"  


  validate do |user|
    errors[:base] << "Login can't be blank" if user.login.blank?
  end
  
  #attr_protected :id
  #attr_protected :salt
  #attr_accessor :password, :password_confirmation
  attr_accessor :password_confirmation
  
  before_save @user.encrypt(self.hashed_password, self.salt) if !@user.nil?
  before_update @user.encrypt(self.hashed_password, self.salt) if !@user.nil?

  def self.authenticate(login, pass)
    u=find_by_login(login)
    return nil if u.nil?
    return u if User.encrypt(pass, u.salt)==u.hashed_password
    nil
  end  

  def password=(pass)
    @password=pass
    self.salt = User.random_string(10) if !self.salt?
    self.hashed_password = User.encrypt(@password, self.salt)
  end

  def send_new_password #(login)
    new_pass = User.random_string(10)
    self.password = self.password_confirmation = new_pass
    self.save
	#self.authenticate(self.login, new_pass)
    #UserMailer.deliver_forgot_password(self.email, self.login, new_pass,Time.now)
	UserMailer.deliver_user_details(self.email, self.login, new_pass,self,Time.now)
  end

  #protected

  def self.encrypt(pass, salt)
    Digest::SHA1.hexdigest(pass+salt)
  end

  def self.random_string(len)
    #generat a random password consisting of strings and digits
    chars = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
    newpass = ""
    1.upto(len) { |i| newpass << chars[rand(chars.size-1)] }
    return newpass
  end

  def self.find_login_by_id(id)
    user_login = User.find_by(id: id)
  end
  
  def create_reset_code
    #@reset = true
    #self.update_attributes!({ :reset_code => Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join ) })
    self.update!({:reset_code => Digest::SHA1.hexdigest( Time.now.to_s.split(//).sort_by {rand}.join ) })
    #self.update #save!(true)
  end 
  
  def delete_reset_code
    self.reset_code = nil
    self.update!({ :reset_code => nil }) #(false)
  end  

end


