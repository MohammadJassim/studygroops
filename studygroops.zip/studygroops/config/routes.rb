Rails.application.routes.draw do
  resources :posts do
    resources :comments
  end
  resources :tasks
  #resources :activities
  resources :group_details
  resources :statuses
  resources :memberships
  #resources :study_groups
  resources :locations

  resources :users
  resources :repositories
  resources :abouts
  resources :activities
  #resources :tasks
  
  resources :study_groups do
    resource :group_details
    resources :activities do
      get 'activities' => 'activities#new'
      get 'activity' => 'activities#edit'
      patch 'activity' => 'activities#update'
      resources :tasks
    end
    #resources :tasks do
      #	get 'new' => 'tasks#new'
      #	get 'task' => 'tasks#new'
      #	patch 'task' => 'tasks#update'
    #end
  end

  resources :tasks do
    get 'new' => 'tasks#new'
    patch 'edit' => 'tasks#update'
  end
  
  get 'contact_form' => 'users#contact_form'
  post 'contact_form' => 'users#contact_form'

  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  root 'study_groups#index'
  get 'id' => 'repositories#index'
  
  get 'download_file' => 'repositories#download_file'
  post 'index' => 'repositories#download_file'

  #resources :activities
  #get 'activity' => 'activities#edit'
  #patch 'activity' => 'activities#update'

  get 'search_by_location' => 'study_groups#search_by_location'
  
  get 'login' => 'users#login'
  post 'login' => 'users#login' 
  get 'destroy' => 'users#destroy'
 
  get 'users' => 'users#index'
  get 'signup' => 'users#signup'
  get 'forgot_password' => 'users#forgot_password'
  post 'forgot_password' => 'users#forgot_password'

  get 'change_password' => 'users#change_password'
  post 'change_password' => 'users#change_password'
 
  get 'reset/:reset_code' => 'users#reset'
  post 'reset/:reset_code' => 'users#reset'

  #get 'users/:id/reset' => 'users#reset', as: :reset
  get 'logout' => 'users#logout'
  #post 'join_group' => 'study_groups#get_user_groups'
  get 'get_user_groups' => 'study_groups#get_user_groups'
 
  get 'get_user_activities' => 'activities#get_user_activities'
  get 'get_user_tasks' => 'tasks#get_user_tasks'
  get 'get_user_posts' => 'posts#get_user_posts'

  #post 'get_user_groups' => 'study_groups#get_user_groups'
  get 'join_group' => 'study_groups#join_group'
  post 'create' => 'study_groups#create'
  get 'leave_group' => 'study_groups#leave_group'
  #post 'leave_group' => 'study_groups#get_user_groups'

  get 'destroy' => 'memberships#destroy'

  resources :study_group do
    resources :posts do
      get 'posts' => 'posts#index'
      patch 'edit' => 'posts#update'
    end
  end
 
  get 'privacypolicy' => 'users#privacypolicy'
  get 'termsconditions' => 'users#termsconditions'
  
  # Example of regular route:
  #   get 'products/:id' => 'catalog#view'

  # Example of named route that can be invoked with purchase_url(id: product.id)
  #   get 'products/:id/purchase' => 'catalog#purchase', as: :purchase

  # Example resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Example resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Example resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Example resource route with more complex sub-resources:
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', on: :collection
  #     end
  #   end

  # Example resource route with concerns:
  #   concern :toggleable do
  #     post 'toggle'
  #   end
  #   resources :posts, concerns: :toggleable
  #   resources :photos, concerns: :toggleable

  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
end
