class CreateAbouts < ActiveRecord::Migration
  def change
    create_table :abouts do |t|
      t.string :index
      t.string :new
      t.string :update
      t.string :edit
      t.string :delete

      t.timestamps
    end
  end
end
