class CreateRepositories < ActiveRecord::Migration
  def change
    create_table :repositories do |t|
      t.string :download_link
      t.string :description

      t.timestamps
    end
  end
end
