class CreateStudyGroups < ActiveRecord::Migration
  def change
    create_table :study_groups do |t|
      t.string :group_name
      t.text :description

      t.timestamps null: false
    end
  end
end
