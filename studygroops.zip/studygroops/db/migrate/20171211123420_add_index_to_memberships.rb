class AddIndexToMemberships < ActiveRecord::Migration
  def change
	add_index :memberships, [:study_group_id, :user_id], :unique => true
  end
end
