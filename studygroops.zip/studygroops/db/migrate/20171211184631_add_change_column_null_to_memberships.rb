class AddChangeColumnNullToMemberships < ActiveRecord::Migration
  def change
    change_column_null :memberships, :study_group_id, false, true
  end
end
