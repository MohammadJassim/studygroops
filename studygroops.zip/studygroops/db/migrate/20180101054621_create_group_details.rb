class CreateGroupDetails < ActiveRecord::Migration
  def change
    create_table :group_details do |t|
      t.references :study_group, index: true, foreign_key: true
      t.datetime :start_date
      t.datetime :end_date
      t.string :location

      t.timestamps null: false
    end
  end
end
