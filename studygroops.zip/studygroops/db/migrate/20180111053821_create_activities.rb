class CreateActivities < ActiveRecord::Migration
  def change
    create_table :activities do |t|
      t.references :study_group, index: true, foreign_key: true
      t.string :activity_name
      t.datetime :activity_date
      t.text :notes
      t.references :status, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
