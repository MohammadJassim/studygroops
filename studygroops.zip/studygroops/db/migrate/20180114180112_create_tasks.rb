class CreateTasks < ActiveRecord::Migration
  def change
    create_table :tasks do |t|
      t.references :activity, index: true, foreign_key: true
      t.text :task_detail
      t.datetime :due_date
      t.text :skills_applied
      t.references :status, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
