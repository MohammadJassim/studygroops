class ChangeColumnNull < ActiveRecord::Migration
  def change
    change_column_null :study_groups, :group_name, false
    change_column_null :study_groups, :description, false
    change_column_null :posts, :title, false
    change_column_null :posts, :content, false
  end
end
