# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180223081217) do

  create_table "abouts", force: :cascade do |t|
    t.string   "index",      limit: 255
    t.string   "new",        limit: 255
    t.string   "update",     limit: 255
    t.string   "edit",       limit: 255
    t.string   "delete",     limit: 255
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "activities", force: :cascade do |t|
    t.integer  "study_group_id", limit: 4
    t.string   "activity_name",  limit: 255
    t.datetime "activity_date"
    t.text     "notes",          limit: 65535
    t.integer  "status_id",      limit: 4
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
  end

  add_index "activities", ["status_id"], name: "index_activities_on_status_id", using: :btree
  add_index "activities", ["study_group_id"], name: "index_activities_on_study_group_id", using: :btree

  create_table "comments", force: :cascade do |t|
    t.integer  "user_id",    limit: 4
    t.text     "body",       limit: 65535
    t.integer  "post_id",    limit: 4
    t.datetime "created_at",               null: false
    t.datetime "updated_at",               null: false
  end

  add_index "comments", ["post_id"], name: "index_comments_on_post_id", using: :btree
  add_index "comments", ["user_id"], name: "index_comments_on_user_id", using: :btree

  create_table "dashboards", force: :cascade do |t|
    t.integer  "study_group_id",     limit: 4
    t.integer  "memberships_id",     limit: 4
    t.integer  "group_name_id",      limit: 4
    t.integer  "created_at_id",      limit: 4
    t.integer  "membership_date_id", limit: 4
    t.integer  "member_count",       limit: 4
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
  end

  add_index "dashboards", ["created_at_id"], name: "index_dashboards_on_created_at_id", using: :btree
  add_index "dashboards", ["group_name_id"], name: "index_dashboards_on_group_name_id", using: :btree
  add_index "dashboards", ["membership_date_id"], name: "index_dashboards_on_membership_date_id", using: :btree
  add_index "dashboards", ["memberships_id"], name: "index_dashboards_on_memberships_id", using: :btree
  add_index "dashboards", ["study_group_id"], name: "index_dashboards_on_study_group_id", using: :btree

  create_table "group_details", force: :cascade do |t|
    t.integer  "study_group_id", limit: 4
    t.datetime "start_date"
    t.datetime "end_date"
    t.string   "location",       limit: 255
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
  end

  add_index "group_details", ["study_group_id"], name: "index_group_details_on_study_group_id", using: :btree

  create_table "locations", force: :cascade do |t|
    t.string   "country",    limit: 255
    t.string   "city",       limit: 255
    t.string   "area",       limit: 255
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "memberships", force: :cascade do |t|
    t.integer  "study_group_id", limit: 4, null: false
    t.integer  "user_id",        limit: 4
    t.datetime "created_at",               null: false
    t.datetime "updated_at",               null: false
  end

  add_index "memberships", ["study_group_id", "user_id"], name: "index_memberships_on_study_group_id_and_user_id", unique: true, using: :btree
  add_index "memberships", ["study_group_id"], name: "index_memberships_on_study_group_id", using: :btree
  add_index "memberships", ["user_id"], name: "index_memberships_on_user_id", using: :btree

  create_table "posts", force: :cascade do |t|
    t.integer  "study_group_id", limit: 4
    t.integer  "user_id",        limit: 4
    t.string   "title",          limit: 255
    t.text     "content",        limit: 65535
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
  end

  add_index "posts", ["study_group_id"], name: "index_posts_on_study_group_id", using: :btree
  add_index "posts", ["user_id"], name: "index_posts_on_user_id", using: :btree

  create_table "repositories", force: :cascade do |t|
    t.string   "download_link", limit: 255
    t.string   "description",   limit: 255
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "statuses", force: :cascade do |t|
    t.string   "state",      limit: 255
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "study_groups", force: :cascade do |t|
    t.string   "group_name",  limit: 255,   null: false
    t.text     "description", limit: 65535, null: false
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
  end

  create_table "tasks", force: :cascade do |t|
    t.integer  "activity_id",    limit: 4
    t.text     "task_detail",    limit: 65535
    t.datetime "due_date"
    t.text     "skills_applied", limit: 65535
    t.integer  "status_id",      limit: 4
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
  end

  add_index "tasks", ["activity_id"], name: "index_tasks_on_activity_id", using: :btree
  add_index "tasks", ["status_id"], name: "index_tasks_on_status_id", using: :btree

  create_table "users", force: :cascade do |t|
    t.string   "login",           limit: 255
    t.string   "hashed_password", limit: 255
    t.string   "email",           limit: 255
    t.string   "salt",            limit: 255
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "reset_code",      limit: 255
  end

  add_foreign_key "activities", "statuses"
  add_foreign_key "activities", "study_groups"
  add_foreign_key "comments", "posts"
  add_foreign_key "comments", "users"
  add_foreign_key "dashboards", "study_groups"
  add_foreign_key "group_details", "study_groups"
  add_foreign_key "posts", "study_groups"
  add_foreign_key "posts", "users"
  add_foreign_key "tasks", "activities"
  add_foreign_key "tasks", "statuses"
end
