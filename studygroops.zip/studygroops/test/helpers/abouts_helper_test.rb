require 'test_helper'

class AboutsHelperTest < ActionView::TestCase
end
