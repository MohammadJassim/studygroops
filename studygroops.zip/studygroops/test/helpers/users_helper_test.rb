require 'test_helper'

class UsersHelperTest < ActionView::TestCase
  # test "should not save user without login" do
  #  user = User.new
  #  assert_not user.save
  # end
end
