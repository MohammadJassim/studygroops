require 'test_helper'

class PostFlowTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end

#  test "can see the login page" do
#    get "/"
#    assert_select "h1", "study_groups#index"
#  end

#  test "can create a post" do
#    get "/study_group/8/posts/new"
#    assert_response :success

#    post "/posts", params: { post: { title: "can create", content: "post successfully.", study_group_id: 8, user_id: 1 } }
 #   assert_response :redirect
 #   follow_redirect!
 #   assert_response :success
#    assert_select "<p>", "Title:\n can create"
  
#  end
end
