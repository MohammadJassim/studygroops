require 'test_helper'

class UserMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "invite" do
    email = UserMailer.create_invite("appsuppose@gmail.com", "m.jassim@gmail.com", Time.now)
    assert_emails 1 do
      email.deliver_now
    end

    assert_equal ['appsuppose@gmail.com'], email.from
    assert_equal ['m.jassim@gmail.com'], email.to
    assert_equal 'You have been invited by appsuppose@gmail.com', email.subject
    assert_equal read_fixture('invite').join, email.body.to_s
    
  end
end
