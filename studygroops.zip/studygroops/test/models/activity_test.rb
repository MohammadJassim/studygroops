require 'test_helper'

class ActivityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "should save new activity" do
    activity = Activity.new
    activity.study_group_id = 298486374
    activity.activity_name = "TestActivity"
    activity.activity_date = "28 March 2018"
    #activity.notes = "note"
    #activity.status_id = 1
    assert activity.save, "Successfully saved activity"
  end

  test "should not save activity without study group id" do
    activity = Activity.new
    #activity.study_group_id = 298486374
    activity.activity_name = "TestActivity"
    activity.activity_date = "28 March 2018"
    activity.notes = "note"
    #activity.status_id = 1
    assert_not activity.save, "Saved activity without study group id"
  end

  test "should not save activity without activity name" do
    activity = Activity.new
    activity.study_group_id = 298486374
    #activity.activity_name = "TestActivity"
    activity.activity_date = "28 March 2018"
    activity.notes = "note"
    #activity.status_id = 1
    assert_not activity.save, "Saved activity without activity_name"
  end

  test "should not save activity without activity date" do
    activity = Activity.new
    activity.study_group_id = 298486374
    activity.activity_name = "TestActivity"
    #activity.activity_date = "28 March 2018"
    activity.notes = "note"
    #activity.status_id = 1
    assert_not activity.save, "Saved activity without activity date"
  end

  
end
