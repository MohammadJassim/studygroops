require 'test_helper'

class CommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "should save new comment" do
    comment = Comment.new
    comment.post_id = 298486374
    comment.user_id = 298486374
    comment.body = "Falaana"
    assert comment.save, "Successfully saved task"
  end

  test "should not save comment without post id" do
    comment = Comment.new
    #comment.post_id = 298486374
    comment.user_id = 298486374
    comment.body = "Falaana"
    assert_not comment.save, "Saved comment without Post id"
  end

  test "should not save comment without user id" do
    comment = Comment.new
    comment.post_id = 298486374
    #comment.user_id = 298486374
    comment.body = "Falaana"
    assert_not comment.save, "Saved comment without user id"
  end

  test "should not save comment without body" do
    comment = Comment.new
    comment.post_id = 298486374
    comment.user_id = 298486374
    #comment.body = "Falaana"
    assert_not comment.save, "Saved comment without body"
  end

end
