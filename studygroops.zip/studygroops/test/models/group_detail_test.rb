require 'test_helper'

class GroupDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "should not save group_detail without location" do
    group_detail = GroupDetail.new
    group_detail.start_date = "28 Feb 2018"
    assert_not group_detail.save, "Saved user without location"
  end

  test "should not save group_detail without start date" do
    group_detail = GroupDetail.new
    group_detail.location = "Some where"
    assert_not group_detail.save, "Saved user without start date"
  end

  test "should save group_detail" do
    group_detail = GroupDetail.new
    group_detail.study_group_id = 298486374
    group_detail.start_date = "28 Feb 2018"
    group_detail.end_date = "22 March 2018"
    group_detail.location = "$%$#$#$##%ˆ"
    assert group_detail.save, "Saved group_detail successfully"
  end

end
