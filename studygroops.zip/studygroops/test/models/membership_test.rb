require 'test_helper'

class MembershipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should save valid ids" do
    membership = Membership.new
    membership.user_id = 298486374 
    membership.study_group_id = 980190962 
    assert membership.save, "Saved Membership with valid ids"    
  end

  test "should not save invalid membership" do
    membership = Membership.new
    assert_not membership.save, "Saved Membership without valid entries"
  end

  #test "should not save invalid ids" do
  #  membership = Membership.new
  #  membership.user_id = 4
  #  membership.study_group_id = 124
  #  assert_not membership.save, "Saved Membership with invalid ids"
  #end


end
