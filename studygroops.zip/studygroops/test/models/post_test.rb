require 'test_helper'

class PostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "save new post" do
    post = Post.new
    post.study_group_id = 298486374
    post.user_id = 298486374
    post.title = "First"
    post.content = "Second"
    assert post.save, "Successfully saved new post."
  end

  test "should not save post without title" do
    post = Post.new
    post.study_group_id = 298486374
    post.user_id = 298486374
    #post.title = "First"
    post.content = "Second"
    assert_not post.save, "Saved post without title"
  end

  test "should not save post without content" do
    post = Post.new
    post.study_group_id = 298486374
    post.user_id = 298486374
    post.title = "First"
    #post.content = "Second"
    assert_not post.save, "Saved post without content."
  end

  test "should not save post without study group id" do
    post = Post.new
    #post.study_group_id = 298486374
    post.user_id = 298486374
    post.title = "First"
    #post.content = "Second"
    assert_not post.save, "Saved post without study_group id."
  end

end
