require 'test_helper'

class StudyGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should save study group" do
    study_group = StudyGroup.new
    study_group.group_name = "Test"
    study_group.description = "Test Group for AI"
    assert study_group.save, "Successfully saved Study Group" 
  end

  test "should not save study group without name" do
    study_group = StudyGroup.new
    study_group.description = "Test Group for AI"
    assert_not study_group.save, "Saved Study Group without group name"
  end

  test "should not save study group without description" do
    study_group = StudyGroup.new
    study_group.group_name = "Test AI"
    assert_not study_group.save, "Saved Study Group without group description"
  end

  test "should not save study group with more than 50 characters" do
    study_group = StudyGroup.new
    study_group.group_name = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaBBBBCCCCCCD"
    study_group.description = "Test Group for AI"
    assert_not study_group.save, "Saved Study Groupi with more than 50 characters"
  end

  test "should not save empty study group" do
    study_group = StudyGroup.new
    assert_not study_group.save, "Saved Study Group without name or description"
  end

  test "should delete study group" do
    study_group = StudyGroup.new
    study_group.group_name = "ToBeDeleted"
    study_group.description = "Test Group for AI"
    study_group.save
    assert study_group.delete
  end

end
