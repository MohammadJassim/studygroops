require 'test_helper'

class TaskTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "should save new task" do
    task = Task.new
    task.activity_id = 298486374
    task.task_detail = "TestActivity"
    task.due_date = "28 March 2018"
    #task.skills_applied = "note"
    #task.status_id = 1
    assert task.save, "Successfully saved task"
  end

  test "should not save task without activity_id" do
    task = Task.new
    #task.activity_id = 298486374
    task.task_detail = "TestActivity"
    task.due_date = "28 March 2018"
    #task.skills_applied = "note"
    #task.status_id = 1
    assert_not task.save, "Successfully saved task"
  end


end
