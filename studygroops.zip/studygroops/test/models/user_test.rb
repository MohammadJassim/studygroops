require 'test_helper'

class UserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  
  test "should not save user without login" do
    user = User.new
    assert_not user.save, "Saved user without login"
  end

  test "should not save user without password" do
    user = User.new
    user.login = "Testog"
    #user.hashed_password = "testpassword01"
    user.password_confirmation = "testpassword01"
    user.email = "Testmail@ghi.co"
    user.salt = "EtxIH"
    assert_not user.save, "Saved without password"
  end

  test "should not save user without password confirmation" do
    user = User.new
    user.login = "Testog"
    user.hashed_password = "testpassword01"
    #user.password_confirmation = "testpassword01"
    user.email = "Testmail@ghi.co"
    user.salt = "EtxIH"
    assert_not user.save, "Saved without password confirmation"
  end

  test "should not save user without valid email" do
    user = User.new
    user.login = "Testog"
    user.hashed_password = "testpassword01"
    user.password_confirmation = "testpassword01"
    user.email = "Testmail@g"
    user.salt = "EtxIH"
    assert_not user.save, "Saved without email"
  end

  test "should not save user without salt" do
    user = User.new
    user.login = "Testog"
    user.hashed_password = "testpassword01"
    user.password_confirmation = "testpassword01"
    user.email = "Testmail@ghi.co"
    #user.salt = "EtxIH"
    assert_not user.save, "Saved without salt"
  end

  test "should save valid user" do
    user = User.new
    user.login = "Testog"
    user.hashed_password = "testpassword01"
    user.password_confirmation = "testpassword01"
    user.email = "Testmail@ghi.co"
    user.salt = "EtxIH"
    assert user.save, "Saved user"
  end


  
end
